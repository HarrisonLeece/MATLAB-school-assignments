
n=20000;
rng(1);
A=rand(n,n);
b1=rand(n,1);
b2=rand(n,1);
b3=rand(n,1);
b4=rand(n,1);
b5=rand(n,1);
b6=rand(n,1);
b7=rand(n,1);
b8=rand(n,1);
b9=rand(n,1);
b10=rand(n,1);

clear n 



